package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Scanner;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }

    Scanner input;
    Lists<Politician> politicians;
    Lists<Election> elections;

    public Main(){
        input = new Scanner(System.in);
        politicians = new Lists<>();
        elections = new Lists<>();
        runMenu();
    }

    public static void main(String[] args) {
        new Main();
        Lists<Politician> politician = new Lists<>();
        //System.out.println(politician.printList(""));
        launch(args);
    }

    private void runMenu(){
        int answer;
        do{
            answer = mainMenu();
            switch(answer){
                case 1:
                    addPolitician();
                    break;
                case 2:
                    listPoliticians();
                    break;
                case 3:
                    deleteAllPoliticians();
                    break;
                case 4:
                    startElection();
                    break;
                case 5:
                    listRunningElections();
                    break;
                case 6:
                    removeElection();
                    break;
                case 7:
                    searchFns();
                    break;
                case 8:
                    try{
                        politicians.save();
                        elections.save();
                    }
                    catch(Exception e){
                        System.err.println("Error writing to file: " + e);
                    }
                    break;
                case 9:
                    try{
                        politicians.load();
                        elections.load();
                    }
                    catch(Exception e){
                        System.err.println("Error loading from file: " + e);
                    }
                    break;
            }
        }
        while(answer != 0);
    }

    private int mainMenu(){
        System.out.println("1) add Politician");
        System.out.println("2) list Politicians");
        System.out.println("3)Delete all Politicians");
        System.out.println("4) Start Election");
        System.out.println("5) list Running Elections");
        System.out.println("6) Remove an election ");
        System.out.println("7) Search");
        System.out.println("----------");
        System.out.println("8) Save");
        System.out.println("9) Load");
        System.out.println("----------");
        System.out.println("0) exit");
        return ScannerInput.readNextInt("==>>");
    }

    public void addPolitician(){
        System.out.println("Name: ");
        String name = input.nextLine();
        System.out.println("Date of Birth: ");
        String dob = input.nextLine();
        System.out.println("Party: ");
        String party = input.nextLine();
        System.out.println("County: ");
        String county = input.nextLine();

        Politician p = new Politician(name, dob, party, county);
        politicians.addElement(p);
    }

    public void listPoliticians(){
        System.out.println("All Politicians: ");
        if(politicians.listPoliticians() != null) {
            System.out.println(politicians.listPoliticians());
        } else {
            System.out.println("no politions found");
        }
    }

    public void deleteAllPoliticians(){
        politicians.deleteAll();
        System.out.println("All politicians deleted!");
    }

    public void startElection(){
        System.out.println("Election Type: ");
        String type = input.nextLine();
        System.out.println("Election Location: ");
        String location = input.nextLine();
        int year = ScannerInput.readNextInt("Year: ");
        int seats = ScannerInput.readNextInt("Number of seats: ");

        Election e = new Election(type, location, year, seats);
        elections.addElement(e);
    }

    public void listRunningElections(){
        System.out.println("All Current Running Elections: ");
        System.out.println(elections.listElections());
    }

    public void removeElection(){
        int index = 0;
        for(int i = 0; i < elections.length(); i++){
            if(elections.head != null){
                index = i;
                System.out.println(index + elections.get(i).toString());
            }
        }
        int x = ScannerInput.readNextInt("Remove?");
        elections.deleteByIndex(x);
    }



    public void searchFns(){
        int v;
        do{
            v=sMenu();
            switch (v){
                case 1:
                    searchPoliticians();
                    break;
                case 2:
                    searchElections();
                    break;
            }
        }
        while (v != 0);
    }

    private int sMenu(){
        System.out.println("   Search:");
        System.out.println("1) search politicians");
        System.out.println("2) search elections");
        System.out.println("0) exit");
        return ScannerInput.readNextInt("===>>");
    }

    public void searchPoliticians() {
        System.out.println("enter search term");
        String userInput = input.nextLine();
        for (int i = 0; i < politicians.length(); i++) {
            if (politicians.get(i).toString().toLowerCase().contains(userInput)) {
                System.out.println(politicians.get(i).toString());
            }
        }
    }

    public void searchElections(){
        System.out.println("enter search term");
        String userInput = input.nextLine();
        for (int i = 0; i < elections.length(); i++) {
            if (elections.get(i).toString().toLowerCase().contains(userInput)) {
                System.out.println(elections.get(i).toString());
            }
        }
    }
}
