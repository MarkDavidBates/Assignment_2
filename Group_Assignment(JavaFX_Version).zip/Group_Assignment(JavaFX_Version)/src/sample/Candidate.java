package sample;

public class Candidate {
}
