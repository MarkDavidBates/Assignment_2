package sample;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Lists<L> {


    public IndividualNode<L> head = null;

    public void addElement(L p){
        IndividualNode<L> ln = new IndividualNode<>();
        ln.setContents(p);
        ln.next = head;
        head = ln;
    }

    /*public String printList(String list){
        IndividualNode current = head;
        String fullList = list + "\n";

        while(current != null){
            list += current.getContents() + "\n";
            current = current.next;
        }
        return list;
    }*/

    public String listPoliticians(){
        if(head == null){
            return "no politicians found...";
        }
        else{
            String listOfPolis = "";
            for(IndividualNode temp = head; temp != null; temp = temp.next){
                listOfPolis = listOfPolis + temp + temp.getContents() + " " + "\n";
            }
            return listOfPolis;
        }
    }

    public String listElections(){
        if(head == null){
            return "";
        }
        else{
            String listOfElections = "";
            for(IndividualNode temp = head; temp != null; temp = temp.next){
                listOfElections = listOfElections + temp + temp.getContents() + ": " + "\n";
            }
            return listOfElections;
        }
    }

    public void deleteAll() {
        head = null;
    }

    public void deleteByIndex(int i){
        IndividualNode<L> temp= head;
        int x =0;
        if(i==0){
            head = temp.next;
        } else {
            while (x < i && temp != null) {
                temp = temp.next;
                x++;
            }
            if (temp != null && temp.next != null) {
                temp.next = temp.next.next;
            }
        }
    }

    public int length(){
        IndividualNode<L> temp= head;
        int i=0;
        for(; temp!=null;i++){
            temp = temp.next;
        }
        return i;
    }


    public L get(int x) {
        int i = 0;
        IndividualNode<L> temp = head;
        while (i < x && temp != null) {
            temp = temp.next;
            i++;
        }
        if (temp != null) {
            return temp.getContents();
        } else {
            return null;
        }
    }


    public void load() throws Exception{
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("data.xml"));
        head = (IndividualNode<L>) is.readObject();
        is.close();
    }

    public void save() throws Exception{
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("data.xml"));
        out.writeObject(head);
        out.close();
    }
}
