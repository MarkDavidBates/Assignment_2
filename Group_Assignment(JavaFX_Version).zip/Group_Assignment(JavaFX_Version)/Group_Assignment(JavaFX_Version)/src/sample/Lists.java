/*
 *  Lists Class used in combination with the IndividualNode class
 *  all requests are done here (adding, listing, removing, searching etc)
 */

package sample;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Lists<L> {


    public IndividualNode<L> head = null;

    public void addElement(L p){
        IndividualNode<L> ln = new IndividualNode<>();
        ln.setContents(p);
        ln.next = head;
        head = ln;
    }

    /*public String printList(String list){
        IndividualNode current = head;
        String fullList = list + "\n";

        while(current != null){
            list += current.getContents() + "\n";
            current = current.next;
        }
        return list;
    }*/

    //code to list all politicians created
    public String listPoliticians(){
        if(head == null){
            return "no politicians found..."; //if the head of the list is null, there are no elements in the list
        }
        else{
            String listOfPolis = "";
            for(IndividualNode temp = head; temp != null; temp = temp.next){ //individual node becomes head when head doesn't equal null
                listOfPolis = listOfPolis + temp + temp.getContents() + " " + "\n";
            }
            return listOfPolis;
        }
    }

    //code to list all running elections
    public String listElections(){
        if(head == null){
            return "";
        }
        else{
            String listOfElections = "";
            for(IndividualNode temp = head; temp != null; temp = temp.next){
                listOfElections = listOfElections + temp + temp.getContents() + ": " + "\n";
            }
            return listOfElections;
        }
    }

    //code to purge all elements in programme
    public void deleteAll() {
        head = null;
    }

    //code to delete elements of a chosen index
    public void deleteByIndex(int i){
        IndividualNode<L> temp= head;
        int x =0;
        if(i==0){
            head = temp.next;
        } else {
            while (x < i && temp != null) {
                temp = temp.next;
                x++;
            }
            if (temp != null && temp.next != null) {
                temp.next = temp.next.next;
            }
        }
    }

    public int length(){
        IndividualNode<L> temp= head;
        int i=0;
        for(; temp!=null;i++){
            temp = temp.next;
        }
        return i;
    }


    public L get(int x) {
        int i = 0;
        IndividualNode<L> temp = head;
        while (i < x && temp != null) {
            temp = temp.next;
            i++;
        }
        if (temp != null) {
            return temp.getContents();
        } else {
            return null;
        }
    }

    //code for saving and loading data into an xml file
    public void load() throws Exception{
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("data.xml"));
        head = (IndividualNode<L>) is.readObject();
        is.close();
    }

    public void save() throws Exception{
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("data.xml"));
        out.writeObject(head);
        out.close();
    }
}
