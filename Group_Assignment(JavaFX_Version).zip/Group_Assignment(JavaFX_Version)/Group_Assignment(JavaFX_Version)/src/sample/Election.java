package sample;

import java.util.Objects;

public class Election {

    private String electionType;
    private String location;
    private int year;
    private int seats;
    //Lists politicians;

    public Election(String electionType, String location, int year, int seats){
        this.electionType = Utilities.max30Chars(electionType);
        this.location = Utilities.max30Chars(location);
        this.year = year;
        this.seats = Utilities.nonNegativeNumber(seats);

        //Candidates
        //politicians = new Lists();


    }

    //getters + setters//

    public String getElectionType() {
        return electionType;
    }

    public void setElectionType(String electionType) { Objects.requireNonNull(this.electionType = electionType); }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {this.location = Utilities.max30Chars(location); }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {this.year = year; }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) { this.seats = Utilities.nonNegativeNumber(seats); }

    public String toString(){
        return "Election Type: " + electionType + "  Location: " + location + "  Year: " + year + "  Number of Seats: " + seats;
    }
}

