package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Scanner;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }

    Scanner input;
    Lists<Politician> politicians;
    Lists<Election> elections;

    public Main(){
        input = new Scanner(System.in);
        politicians = new Lists<>(); //creates list for politicians
        elections = new Lists<>(); //creates list for elections
        runMenu();
    }

    public static void main(String[] args) {
        new Main();
        Lists<Politician> politician = new Lists<>();
        launch(args);
    }

    private void runMenu(){
        int answer;
        do{
            answer = mainMenu();
            switch(answer){
                case 1:
                    addPolitician();
                    break;
                case 2:
                    listPoliticians();
                    break;
                case 3:
                    startElection();
                    break;
                case 4:
                    listRunningElections();
                    break;
                case 5:
                    deleteFns();
                    break;
                case 6:
                    searchFns();
                    break;
                case 7:
                    try{
                        politicians.save();
                        elections.save();
                    }
                    catch(Exception e){
                        System.err.println("Error writing to file: " + e);
                    }
                    break;
                case 8:
                    try{
                        politicians.load();
                        elections.load();
                    }
                    catch(Exception e){
                        System.err.println("Error loading from file: " + e);
                    }
                    break;
            }
        }
        while(answer != 0);
    }

    private int mainMenu(){
        System.out.println("1) add Politician");
        System.out.println("2) list Politicians");
        System.out.println("3) Start Election");
        System.out.println("4) list Running Elections");
        System.out.println("5) Delete");
        System.out.println("6) Search");
        System.out.println("----------");
        System.out.println("7) Save");
        System.out.println("8) Load");
        System.out.println("----------");
        System.out.println("0) exit");
        return ScannerInput.readNextInt("==>>");
    }

    //ui for adding politicians
    public void addPolitician(){
        System.out.println("Name: ");
        String name = input.nextLine();
        System.out.println("Date of Birth: ");
        String dob = input.nextLine();
        System.out.println("Party: ");
        String party = input.nextLine();
        System.out.println("County: ");
        String county = input.nextLine();

        Politician p = new Politician(name, dob, party, county);
        politicians.addElement(p); //uses code in the Lists class to add a new element to the politicians list
    }
    
    public void listPoliticians(){
        System.out.println("All Politicians: ");
        System.out.println(politicians.listPoliticians());
    }

    public void resetLists(){
        politicians.deleteAll();
        elections.deleteAll();
        System.out.println("Lists cleared!");
    }

    public void startElection(){
        System.out.println("Election Type: ");
        String type = input.nextLine();
        System.out.println("Election Location: ");
        String location = input.nextLine();
        int year = ScannerInput.readNextInt("Year: ");
        int seats = ScannerInput.readNextInt("Number of seats: ");

        Election e = new Election(type, location, year, seats);
        elections.addElement(e);
    }

    public void listRunningElections(){
        System.out.println("All Current Running Elections: ");
        System.out.println(elections.listElections());
    }

    public void removeElection(){
        int index = 0;
        for(int i = 0; i < elections.length(); i++){
            if(elections.head != null){
                index = i;
                System.out.println(index + elections.get(i).toString()); //when elections list is not null, print all elements in list with index
            }
        }
        int x = ScannerInput.readNextInt("Remove?"); //input index/number of the element you want to delete
        elections.deleteByIndex(x);
    }

    public void removePolitician(){
        int index = 0;
        for(int i = 0; i < politicians.length(); i++){
            if(elections.head != null){
                index = i;
                System.out.println(index + politicians.get(i).toString());
            }
        }
        int x = ScannerInput.readNextInt("Remove?");
        politicians.deleteByIndex(x);
    }

    public void searchFns(){
        int v;
        do{
            v=sMenu();
            switch (v){
                case 1:
                    searchPoliticians();
                    break;
                case 2:
                    searchElections();
                    break;
            }
        }
        while (v != 0);
    }

    private int sMenu(){
        System.out.println("   Search:");
        System.out.println("1) search politicians");
        System.out.println("2) search elections");
        System.out.println("0) exit");
        return ScannerInput.readNextInt("===>>");
    }

    public void deleteFns()
    {
        int u;
        do{
            u = dMenu();
            switch (u){
                case 1:
                    removePolitician();
                    break;
                case 2:
                    removeElection();
                    break;
                case 3:
                    resetLists();
                    break;
            }
        }
        while (u != 0);
    }

    private int dMenu(){
        System.out.println("1) delete politician");
        System.out.println("2) delete election");
        System.out.println("3) delete all");
        System.out.println("0) exit");
        return ScannerInput.readNextInt("===>>");
    }

    public void searchPoliticians() {
        System.out.println("enter search term");
        String userInput = input.nextLine(); //input key element you want to search for
        for (int i = 0; i < politicians.length(); i++) {
            if (politicians.get(i).toString().toLowerCase().contains(userInput)) {
                System.out.println(politicians.get(i).toString()); //print politician if it contains key element searched for
            }
        }
    }

    public void searchElections(){
        System.out.println("enter search term");
        String userInput = input.nextLine();
        for (int i = 0; i < elections.length(); i++) {
            if (elections.get(i).toString().toLowerCase().contains(userInput)) {
                System.out.println(elections.get(i).toString());
            }
        }
    }
}
